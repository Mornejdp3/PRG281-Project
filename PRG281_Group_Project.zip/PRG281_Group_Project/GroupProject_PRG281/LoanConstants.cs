﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject_PRG281
{
    // Created constant variables, gets its values from the derived class, LoanConstants
    public interface ILoanConstants
    {
        int shortTerm { get; }
        int mediumTerm { get; }
        int longTerm { get; }
        int maxLoanAmount { get; }
        string companyName { get; }
    }

    // Returns the constant values
    public  class LoanConstants: ILoanConstants
    {
        // Short term == 1 year
        public int shortTerm { get { return 1; } }
        // Medium term == 3 years
        public int mediumTerm { get { return 3; } }
        // Long term == 5 years
        public int longTerm { get { return 5; } }
        // Max Loan == R100000
        public int maxLoanAmount { get { return 100000; } }
        // Company Name == Unique Building Services Loan Company
        public string companyName{ get { return "Unique Building Services Loan Company"; } }

        
    }

}
