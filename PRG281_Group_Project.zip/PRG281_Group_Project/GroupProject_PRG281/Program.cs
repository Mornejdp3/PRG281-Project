﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace GroupProject_PRG281
{
    // Students

    //Calvin Jordaan – 577859
    //Dylan Cheballah – 577424
    //Hrudhay Reddy – 577833
    //Morne du Plessis - 577299
    //Nontsikelelo Sharon Buhlungu - 577878

    // Enum used to navigate through the different options
    public enum Menu
    {
        LoanPersonal = 1,
        LoanBusiness,
        DisplayCurrentLoans,
        Exit
    }
    internal class Program
    {
        // Different global variables used by the program
        public static int loanTerm, userChoice, count = 0, personLoanCount = 0, businessLoanCount = 0;
        public static string loanNr, custLastName, custFirstName, checkItem, text, textTitle;
        public static decimal loanAmount, primeInterestRate;
        public static bool businessLoanSelected = false, personLoanSelected = false, displayTime = true;

        static void Main(string[] args)
        {
            // Used to allow the program to loop until the user has entered the specified amount of loan objects
            bool runPro = true;
            // The array is used to store all the loan objects
            string[] loanArr = new string[5];

            // Loan constants object used to get the constant values in the interface class (The company name)
            ILoanConstants loanConstants = new LoanConstants();

            // A thread created to display the date an time on the first page of the program
            Thread dateThread = new Thread(displayDate);
            
            // First Page, display company name, date and time
            Console.WriteLine(loanConstants.companyName + " welcomes you to our loan application");
            Console.WriteLine("------------------------------------------------------------------------------------------------");
            Console.WriteLine("Press enter to start the application:");
            Console.WriteLine("------------------------------------------------------------------------------------------------");

            // Starts the thread
            dateThread.Start();

            // Requires the user to press enter to allow the console to be cleared
            Console.ReadLine();

            // Allows the created thread to end
            displayTime = false;

            Console.Clear();

            // Gets the title of the page and is used by a method to display it
            textTitle = "Select prime interest rate:";
            // If a user does not follow the correct process these variables allows the method doing error checking to return the question,
            // instead of displaying a blank page
            text = "Please enter the prime interest rate";

            // Method called returning the values and allows error handling
            primeInterestRate = checkforCharDeci(text);

            // This is the start of the loop allowing the program to run until all the conditions are met
            while(runPro == true)
            {
                // The count variable allows the program to store only 5 objects, before displaying them
                if(count < 5)
                {
                    // The following is text that asks the user to choose one of the available options
                    Console.Clear();
                    // Used to display the amount of entries still left
                    Console.WriteLine("Number of enteries left: " + (5 - count));
                    Console.WriteLine("---------------------------------------------------");
                    textTitle = "Select an option:";
                    text = "Please select one of the following options:\n1. Personal Loan\n2. Business Loan\n3. Display Current Loans\n4. Exit";

                    // The following method checks the user input for errors before using it in the switch case
                    userChoice = checkforCharInt(text);

                    // The switch case is used to display the user's selected option
                    switch (userChoice)
                    {
                        // Add Personal Loan
                        case (int)Menu.LoanPersonal:
                            {
                                Console.Clear();
                                // This boolean value allows the program to differentiate between Personal- and Business Loans
                                personLoanSelected = true;

                                textTitle = "You have selected personal loan";

                                // Prompts the user the different questions that they have to answer
                                enterInfo();

                                Console.Clear();

                                // Information is then sent to the personal loan class, to be used
                                Loan newLoan = new PersonalLoan(loanNr, loanTerm, custLastName, custFirstName, loanAmount, primeInterestRate);

                                Console.WriteLine("---------------------------------------------------");

                                // If the user has entered a larger value than 100000 it will not be saved
                                if (newLoan.ToString().Substring(0, 1) != "L")
                                {
                                    // This will display the user inputs and add the retured value to the array
                                    Console.WriteLine(newLoan.ToString());
                                    loanArr[count] = newLoan.ToString();
                                    count++;
                                }
                                else
                                {
                                    // This will warn the user
                                    Console.WriteLine(newLoan.ToString());
                                }

                                // Resets the selected loan
                                personLoanSelected = false;

                                break;
                            }
                        // Add Business Loan
                        case (int)Menu.LoanBusiness:
                            {
                                // This part will run if the user selected the business loan option
                                Console.Clear();

                                // Indicates that the user has selected a business loan to certain parts of the program
                                businessLoanSelected = true;

                                textTitle = "You have selected business loan";

                                // Prompts the user different questions that they have to answer
                                enterInfo();

                                Console.Clear();

                                // Send the information to the Business Loan class and creates an object
                                Loan newLoan = new BusinessLoan(loanNr, loanTerm, custLastName, custFirstName, loanAmount, primeInterestRate);

                                Console.WriteLine("---------------------------------------------------");

                                // If the user has entered a larger value than 100000 it will not be saved
                                if (newLoan.ToString().Substring(0, 1) != "L")
                                {
                                    // This will display the user inputs and add the retured value to the array
                                    Console.WriteLine(newLoan.ToString());
                                    loanArr[count] = newLoan.ToString();
                                    count++;
                                }
                                else
                                {
                                    // This will warn the user
                                    Console.WriteLine(newLoan.ToString());
                                }
                                // Resets the selected loan
                                businessLoanSelected = false;

                                break;
                            }
                        // Display the currently added loans
                        case (int)Menu.DisplayCurrentLoans:
                            {

                                // Avoids errors if no items have been added yet
                                if (loanArr[0] != null)
                                {

                                    // The following will display only the entered loans
                                    for (int j = 0; j < count; j++)
                                    {
                                        // Displays the following if there is an created loan
                                        // Checks what type of loan has been added
                                        if (loanArr[j].Substring(17, 2) == "bl")
                                        {
                                            Console.WriteLine("Loans that have been created:");
                                            Console.WriteLine("\n---------------------------------------------------");
                                            Console.WriteLine("Business Loan");
                                            Console.WriteLine("---------------------------------------------------");
                                        }
                                        else
                                        {
                                            Console.WriteLine("\n---------------------------------------------------");
                                            Console.WriteLine("Personal Loan");
                                            Console.WriteLine("---------------------------------------------------");
                                        }
                                        Console.WriteLine(loanArr[j]);
                                    }
                                }
                                else
                                {
                                    // Displays the following if there are no loan entries
                                    Console.WriteLine("---------------------------------------------------");
                                    Console.WriteLine("No loans have been added");
                                }
                                    
                                    
                                break;
                            }
                        // Exit Program
                        case (int)Menu.Exit:
                            {
                                // The following is displayed if the user selected the exit option
                                Console.Clear();
                                Console.WriteLine("You have selected exit application");
                                Console.WriteLine("---------------------------------------------------");
                                Console.WriteLine("Thank you for using the application");
                                Console.WriteLine("---------------------------------------------------");
                                Console.WriteLine("Please press enter to continue");
                                Console.ReadLine();
                                // Allows the program to exit
                                Environment.Exit(1);
                                break;
                            }
                        // Default - If user does not select one of the given options
                        default:
                            {
                                // The following displays if the user did not select one of the given options
                                Console.WriteLine("Please choose from the allocated options.");
                                break;
                            }
                    }

                    // This text will always follow after an business- or personal loan has been added
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine("Please press enter to continue");
                    Console.ReadLine();
                }
                else
                {
                    // If the entries are full the program will then display the following

                    Console.Clear();
                    Console.WriteLine("Loans that have been created:");
                    Console.WriteLine("---------------------------------------------------");

                    // The following is a for loop used to display all the loan entries
                    for(int i = 0; i < 5; i++)
                    {
                        // Checks for the type of the loan
                        if(loanArr[i].Substring(17, 2) == "bl")
                        {
                            Console.WriteLine("\n---------------------------------------------------");
                            Console.WriteLine("Business Loan");
                            Console.WriteLine("---------------------------------------------------");
                        }
                        else
                        {
                            Console.WriteLine("\n---------------------------------------------------");
                            Console.WriteLine("Personal Loan");
                            Console.WriteLine("---------------------------------------------------");
                        }

                        // Displays the stored item in the array
                        Console.WriteLine(loanArr[i]);
                        Console.WriteLine("---------------------------------------------------");
                    }

                    // Allows the program to finish
                    runPro = false;
                }
                
            }

            // At the of the program this will display
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("Thank you for using the application");
            Console.WriteLine("---------------------------------------------------");
            Console.WriteLine("Please press enter to continue");
            Console.ReadLine();
        }

        // Thsi method is called when the user wants to enter information of a loan
        public static void enterInfo()
        {
            // First Name
            text = "First Name:";
            custFirstName = checkforCharStr(text);

            // Last Name
            text = "Last Name:";
            custLastName = checkforCharStr(text);

            // Loan Amount
            text = "Loan Amount (Max amount R100000):";
            loanAmount = checkforCharDeci(text);

            // Loan Term
            text = "Loan Term: (1 / 3 or 5 Years)";
            loanTerm = checkforCharInt(text);

            // Loan number --> Given automatically
            Console.WriteLine("Your loan number is:");

            // Checks what the type is of the loan entry
            if (personLoanSelected == true)
            {
                // Increments the personal loan number by one each time a new personal loan has been added
                personLoanCount = personLoanCount + 1;
                loanNr = "pl: " + personLoanCount;
            }
            else
            {
                //Increments the business loan number by one each time a new personal loan has been added
                businessLoanCount = businessLoanCount + 1;
                loanNr = "bl: " + businessLoanCount;

            }
            
        }


        // Error handling for intiger values
        public static int checkforCharInt(string textDesc)
        {
            // Used to check the given question has been entered correctly
            bool checkQuest = true;
            int val = 0;

            while (checkQuest == true)
            {
                
                Console.WriteLine(textTitle);
                Console.WriteLine("---------------------------------------------------");
                Console.WriteLine(textDesc);
                checkItem = Console.ReadLine();

                try
                {
                    //Process
                    val = int.Parse(checkItem);

                    if (val > 0)
                    {
                        checkQuest = false;

                    }
                    else if (val < 0 && val != -1)
                    {
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("Please avoid using negative values");
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("Please press enter to continue");
                        Console.ReadLine();

                        Console.Clear();
                    }
                    else
                    {
                    }
                }
                catch (Exception err)
                {
                    // Error
                    Console.WriteLine("------------------- Error -------------------------");
                    Console.WriteLine(err);
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine("Please make sure not to use any characters");
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine("Please press enter to continue");
                    Console.ReadLine();
                    Console.Clear();
                }
            }
            Console.Clear();
            return val;
        }

        // Error handling for decimal values
        public static decimal checkforCharDeci(string textDesc)
        {
            // Used to check the given question has been entered correctly
            bool checkQuest = true;
            decimal val = 0;

            while (checkQuest == true)
            {
                try
                {
                    // Process
                    Console.WriteLine(textTitle);
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine(textDesc);
                    checkItem = Console.ReadLine();
                    val = decimal.Parse(checkItem);

                    if (val > 0)
                    {
                        checkQuest = false;

                    }
                    else if (val < 0)
                    {
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("Please avoid using negative values");
                        Console.WriteLine("---------------------------------------------------");
                        Console.WriteLine("Please press enter to continue");
                        Console.ReadLine();

                        Console.Clear();
                    }
                    else
                    {
                    }

                }
                catch (Exception err)
                {
                    //Error
                    Console.WriteLine("------------------- Error -------------------------");
                    Console.WriteLine(err);
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine("Please make sure not to use any characters");
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine("Please press enter to continue");
                    Console.ReadLine();
                    Console.Clear();

                }


            }
            Console.Clear();
            return val;
        }

        // Error handling for string values
        public static string checkforCharStr(string textDesc)
        {
            // Used to check the given question has been entered correctly
            bool checkQuest = true;
            string val = "";

            while (checkQuest == true)
            {
                try
                {
                    // Process
                    Console.WriteLine(textTitle);
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine(textDesc);
                    checkItem = Console.ReadLine();
                    if (checkItem == "") throw new ApplicationException("Please enter the proper information.");
                    val = checkItem;
                    checkQuest = false;
                }
                catch (ApplicationException err)
                {
                    // Error
                    Console.WriteLine("------------------- Error -------------------------");
                    string error = err.ToString();
                    Console.WriteLine(error.Substring(29, 39));
                    Console.WriteLine("---------------------------------------------------");
                    Console.WriteLine("Please press enter to continue");
                    Console.ReadLine();
                    Console.Clear();

                }


            }
            Console.Clear();
            return val;
        }

        // Method that is used by the created thread allowing the date to be updated every second
        public static void displayDate()
        {

            while(displayTime == true)
            {
                Console.SetCursorPosition(20, 2);
                Console.Write("                                                     ");
                Console.SetCursorPosition(20, 2);
                Console.Write("     Date: " + DateTime.Now);
                Thread.Sleep(1000);
            }
            
        }
    }
}